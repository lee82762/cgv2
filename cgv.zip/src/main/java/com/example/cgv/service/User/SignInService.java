package com.example.cgv.service.User;

import com.example.cgv.domain.dto.User.LoginDto;
import com.example.cgv.domain.dto.User.SignInDto;
import com.example.cgv.domain.entity.User;
import com.example.cgv.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class SignInService {
    private final UserRepository userRepository;

    public SignInService(UserRepository userRepository){

        this.userRepository = userRepository;
    }

    public LoginDto SignIn(SignInDto signInDto){
       // User user=userRepository.findById(signInDto.getUserID());
        User user=userRepository.findByUserID("woqja");
        if(user==null){
            log.info("존재하지 않는 아이디 입니다.");
            System.out.println("존재 하지 않는 아이디 입니다.");

        }
        if(!(user.getPassword().equals(signInDto.getPassword()))){
            log.info("비밀번호가 일치하지 않습니다.");

        }
        return new LoginDto(user.getUserID(),user.getPassword());
    }
}
