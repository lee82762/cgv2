package com.example.cgv.service.User;

import com.example.cgv.domain.entity.User;
import com.example.cgv.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class UserDeleteService {
    private final UserRepository userRepository;

    public UserDeleteService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    public void UserDelete(){
        String user1="dpwn";
        User user= userRepository.findByUserID(user1);

            log.info("회원 탈퇴 완료");
            userRepository.delete(user);

    }
}
