package com.example.cgv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CgvApplication {

    public static void main(String[] args) {
        SpringApplication.run(CgvApplication.class, args);
    }

}
