package com.example.hanium;


import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Join extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);
    }



    public void Click_register(View v) {
        EditText username = (EditText) findViewById(R.id.username);
        String name=username.getText().toString();

        EditText userid = (EditText) findViewById(R.id.userid);
        String id=userid.getText().toString();

        EditText password = (EditText) findViewById(R.id.password);
        String pw=password.getText().toString();

        EditText usermail = (EditText) findViewById(R.id.usermail);
        String mail=usermail.getText().toString();

        EditText userphone = (EditText) findViewById(R.id.phone);
        String phone=userphone.getText().toString();

        EditText useraddr = (EditText) findViewById(R.id.address);
        String addr=useraddr.getText().toString();

        if((name.length()!=0)&&(id.length()!=0)&&(pw.length()!=0)&&(mail.length()!=0)) {

            /*new AlertDialog.Builder(Join.this)
                    .setMessage("가입완료되었습니다.")
                    .show();*/
            Toast.makeText(getApplicationContext(), "가입이 완료되었습니다.", Toast.LENGTH_LONG).show();


            Intent intent = new Intent(getApplicationContext(), Login.class);
            startActivity(intent);
        }
        else{
            new AlertDialog.Builder(Join.this)
                    .setMessage("필수 입력칸을 채워주세요")
                    .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which){
                            Toast.makeText(getApplicationContext(), "확인 누름", Toast.LENGTH_SHORT).show();
                        }
                    })

                    .show();
        }
    }
}