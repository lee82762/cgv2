package org.techtown.hanium;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.techtown.hanium.domain.source.user.SignUpRemoteDataSource;
import org.techtown.hanium.domain.user.dto.SignUpDto;

public class SignUpActivity extends AppCompatActivity {

    private Context context;

    private EditText id, password, passwordCheck, email, name, address, phone;

    private Button join;

    private SignUpDto signUpDto;

    private SignUpRemoteDataSource signUpRemoteDataSource;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        init();
    }

    private void init() {

        context = getApplicationContext();
        signUpRemoteDataSource = new SignUpRemoteDataSource(context);

        id = (EditText) findViewById(R.id.editTextSignId);
        password = (EditText) findViewById(R.id.editTextSignPassword);
        passwordCheck = (EditText) findViewById(R.id.editTextSignPasswordCheck);
        name = (EditText) findViewById(R.id.editTextSignName);
        address = (EditText) findViewById(R.id.editTextSignAddress);
        email = (EditText) findViewById(R.id.editTextSignEmail);
        phone = (EditText) findViewById(R.id.editTextSignPhone);

        join = (Button) findViewById(R.id.buttonJoin);

        join.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                signUpDto = new SignUpDto(address.getText().toString(),
                        email.getText().toString(),
                        name.getText().toString(),
                        password.getText().toString(),
                        phone.getText().toString(),
                        id.getText().toString());

                System.out.println(address.getText().toString());

                signUpRemoteDataSource.signUp(signUpDto);
            }
        });
    }
}
