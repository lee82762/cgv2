package org.techtown.hanium;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.techtown.hanium.domain.user.dto.SignUpDto;
import org.techtown.hanium.network.RetrofitConnection;

import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Callback;

public class Join extends AppCompatActivity {
    private Button register_button;
    private static final String TAG = "Join";
    //AlertDialog.Builder builder = new AlertDialog.Builder(this);

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);

//        //로그인화면에서 회원가입창으로 넘기기
//        Intent intent = getIntent();
//
//        register_button = findViewById(R.id.btn_register);
//        register_button.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                //editText에 입력되어있는 값을 get해옴
//                EditText id = (EditText) findViewById(R.id.id);
//                String ID = id.getText().toString();
//
//                EditText password = (EditText) findViewById(R.id.password);
//                String PW = password.getText().toString();
//
//                EditText password_check = (EditText) findViewById(R.id.password_check);
//                String PW_check = password.getText().toString();
//
//                EditText email = (EditText) findViewById(R.id.email);
//                String Email = email.getText().toString();
//
//                EditText phone_number = (EditText) findViewById(R.id.phone_number);
//                String Phone_number = phone_number.getText().toString();
//
//                EditText address = (EditText) findViewById(R.id.address);
//                String Address = address.getText().toString();
//
//                EditText name = (EditText) findViewById(R.id.name);
//                String Name = address.getText().toString();
//
//                //서버로 retrofit이용해서 요청
//                RetrofitConnection retrofitConnection = new RetrofitConnection();
//                SignUpDto userData = new SignUpDto(Address, Email, Name, PW, Phone_number, ID);
//                Call<Void> call = retrofitConnection.server.postData(userData);
//                call.enqueue(new Callback<Void>() {
//                    @Override
//                    public void onResponse(Call<Void> call, Response<Void> response) {
//                        if (response.isSuccessful()) {
//                            // 성공적으로 서버에서 데이터 불러옴.
//
//
//                        } else {
//                            // 서버와 연결은 되었으나, 오류 발생
//
//                        }
//                    }
//                    @Override
//                    public void onFailure(Call<Void> call, Throwable t) {
//                        Log.d(TAG, "onFailure: " + t.toString()); //서버와 연결 실패
//                    }
//                });
//            }
//        });

    }
}