package org.techtown.hanium.network;


import org.techtown.hanium.domain.user.dto.SignInDto;
import org.techtown.hanium.domain.user.dto.SignUpDto;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface RetrofitAPI {

    @POST("movie/user/signUp") //회원가입
    Call<Void> callSignUp(@Body SignUpDto signUpDto);

    @POST("movie/user/signIn") //로그인
    Call<Void> callSignIn(@Body SignInDto signInDto);
}
