package org.techtown.hanium.network;


import org.techtown.hanium.domain.user.dto.SignUpDto;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface RetrofitAPI {

    @POST("movie/user/signUp")
    Call<Void> callSignUp(@Body SignUpDto signUpDto);

    //Call<org.techtown.hanium.domain.user.dto.UserData> get_data();
}
