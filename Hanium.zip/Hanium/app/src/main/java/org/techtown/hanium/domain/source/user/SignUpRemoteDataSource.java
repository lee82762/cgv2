package org.techtown.hanium.domain.source.user;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;

import org.techtown.hanium.domain.user.dto.SignUpDto;
import org.techtown.hanium.network.RetrofitConnection;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignUpRemoteDataSource {

    Context context;
    private SharedPreferences userInformation;
    private SharedPreferences.Editor loginEditor;

    public SignUpRemoteDataSource(Context context) {
        this.context = context;
    }

    public void signUp(SignUpDto signUpDto) {

        Call<Void> response = RetrofitConnection.getInstance()
                .getRetrofitApiService().callSignUp(signUpDto);

        Toast.makeText(context, signUpDto.getAddress() + "", Toast.LENGTH_SHORT).show();

        response.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if(response.isSuccessful()) {
                    Toast.makeText(context, "회원가입 성공!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, "회원가입 실패!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(context, "통신 실패!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
