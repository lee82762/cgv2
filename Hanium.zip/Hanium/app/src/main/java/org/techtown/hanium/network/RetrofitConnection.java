package org.techtown.hanium.network;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitConnection {
    private final String URL = "http://192.168.0.10:8080/"; // 서버 API

//    Retrofit retrofit = new Retrofit.Builder()
//            .baseUrl(URL)
//            .addConverterFactory(GsonConverterFactory.create())
//            .build();

    private static final RetrofitConnection INSTANCE = new RetrofitConnection();

    private RetrofitAPI retrofitAPI;

    // 통신을 할 시 json 사용과 해당 객체로의 파싱을 위해 생성
    private Gson gson = new GsonBuilder()
            .setLenient()
            .create();

    public static RetrofitConnection getInstance() {
        return INSTANCE;
    }

    private Retrofit retrofit = new Retrofit.Builder()
            .baseUrl(URL)   // 서버 주소
            .addConverterFactory(GsonConverterFactory.create(gson)) // Json 사용을 위해 ConvertFactory 추가
            .build();

    // api 사용을 위한 서비스 생성 => 싱글톤
    public RetrofitAPI getRetrofitApiService() {
        if (retrofitAPI == null) {
            retrofitAPI = retrofit.create(RetrofitAPI.class);
        }
        return retrofitAPI;
    }


//    RetrofitAPI server = retrofit.create(RetrofitAPI.class);

}
