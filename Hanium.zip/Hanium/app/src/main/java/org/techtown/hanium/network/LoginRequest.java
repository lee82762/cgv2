package org.techtown.hanium.network;

public class LoginRequest {
}
