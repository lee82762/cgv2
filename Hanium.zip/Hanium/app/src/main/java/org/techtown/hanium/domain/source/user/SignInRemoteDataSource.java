package org.techtown.hanium.domain.source.user;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;

import org.techtown.hanium.domain.user.dto.SignInDto;
import org.techtown.hanium.network.RetrofitConnection;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignInRemoteDataSource {

    Context context;
    private SharedPreferences userInformation;
    private SharedPreferences.Editor user;


    public SignInRemoteDataSource(Context context) {

        this.context = context;
    }

    public void signIn(SignInDto signInDto) {

        Call<Void> response = RetrofitConnection.getInstance()
                .getRetrofitApiService().callSignIn(signInDto);

        Log.d("LoginCheckCheck444", "grg");


        response.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if(response.isSuccessful()) {
                   Toast.makeText(context, "로그인 성공!", Toast.LENGTH_SHORT).show();

                }
                else {

                    Toast.makeText(context, "로그인 실패!", Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(context, "통신 실패!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
