package org.techtown.hanium.domain.source.user;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

public class SignInRemoteDataSource {

    Context context;
    private SharedPreferences userInformation;
    private SharedPreferences.Editor user;

    public SignInRemoteDataSource(Context context) {
        this.context = context;
    }

    public void singIn(SignInDto signInDto) {

        Call<LoginDto> response = NetRetrofit.getInstance().getNetRetrofitInterface().singIn(signInDto);

        Log.d("LoginCheckCheck444", "grg");
        response.enqueue(new Callback<LoginDto>() {
            @Override
            public void onResponse(Call<LoginDto> call, Response<LoginDto> response) {
                if(response.isSuccessful()) {
                   user.putString("Name", response.body().getName());
                   user.commit();
                }
                else {


                }
            }

            @Override
            public void onFailure(Call<LoginDto> call, Throwable t) {

            }
        });
    }
}
